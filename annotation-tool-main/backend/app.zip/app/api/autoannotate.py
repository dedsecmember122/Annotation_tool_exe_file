"""
Auto-annotate router:
  POST /api/projects/{id}/train                — kick off training job
  GET  /api/projects/{id}/train/status         — poll latest job
  GET  /api/projects/{id}/annotation-stats     — counts for loop decisions
  POST /api/images/{id}/auto-annotate          — run inference on one image
  POST /api/projects/{id}/auto-annotate-batch  — run inference on all unannotated images
"""
import json
import threading
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.app.api.auth import current_user_dep
from backend.app.core.config import get_settings
from backend.app.db import SessionLocal, get_db
from backend.app.models.models import Annotation, Image, LabelClass, ModelVersion, TrainingJob, User
from backend.app.schemas.schemas import TrainingJobOut

router = APIRouter(tags=["autoannotate"])
settings = get_settings()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _load_latest_model_version(project_id: int, db: Session):
    """Return latest ModelVersion for this project, or None."""
    return (
        db.query(ModelVersion)
        .filter(ModelVersion.project_id == project_id)
        .order_by(ModelVersion.version_number.desc())
        .first()
    )


def _build_adapter(model_version: ModelVersion):
    """Load the CustomModelAdapter from checkpoint stored in model_version."""
    from backend.app.ml.custom_model_adapter import CustomModelAdapter

    adapter = CustomModelAdapter()
    meta = json.loads(model_version.metrics or "{}")
    class_names = meta.get("classes") or ["license_plate"]
    nc = meta.get("nc") or len(class_names)

    if settings.CUSTOM_MODEL_DIR:
        adapter.load(
            settings.CUSTOM_MODEL_DIR,
            class_names=class_names,
            nc=nc,
            weights_path=model_version.checkpoint_path or None,
        )
    else:
        raise RuntimeError("CUSTOM_MODEL_DIR not configured in settings.")
    return adapter


# ─────────────────────────────────────────────────────────────────────────────
# Background training
# ─────────────────────────────────────────────────────────────────────────────

def _run_training(job_id: int, project_id: int, epochs: int = 60) -> None:
    db = SessionLocal()
    try:
        job = db.query(TrainingJob).filter(TrainingJob.id == job_id).first()
        if not job:
            return
        job.status = "running"
        job.started_at = datetime.now(timezone.utc)
        db.commit()

        log_buffer = ["Training job started...\n"]
        
        def handle_log(line: str):
            log_buffer.append(line)
            # Update DB periodically (e.g. every 10 lines) to stream logs live to UI
            if len(log_buffer) % 10 == 0:
                try:
                    with SessionLocal() as local_db:
                        j = local_db.query(TrainingJob).filter(TrainingJob.id == job_id).first()
                        if j:
                            j.log = "".join(log_buffer)
                            local_db.commit()
                except Exception:
                    pass

        from backend.app.ml.training_manager import TrainingManager
        tm = TrainingManager(project_id, db)
        result = tm.train(epochs=epochs, log_callback=handle_log)

        log = (
            "".join(log_buffer) + "\n\n" +
            f"Training completed.\n"
            f"Trained on {result['trained_on']} images.\n"
            f"Classes ({result['nc']}): {', '.join(result['classes'])}\n"
            f"Checkpoint: {result['checkpoint']}"
        )

        job.status = "completed"
        job.completed_at = datetime.now(timezone.utc)
        job.log = log
        db.commit()

    except Exception as exc:
        db = SessionLocal()
        job = db.query(TrainingJob).filter(TrainingJob.id == job_id).first()
        if job:
            job.status = "failed"
            # Append the exception to what we already captured instead of replacing it
            job.log = "".join(log_buffer) + f"\n\n[ERROR]: {str(exc)}"
            job.completed_at = datetime.now(timezone.utc)
            db.commit()
    finally:
        db.close()


# ─────────────────────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/projects/{project_id}/train", response_model=TrainingJobOut, status_code=202)
def start_training(
    project_id: int,
    epochs: int = 60,
    db: Session = Depends(get_db),
    user: User = Depends(current_user_dep),
) -> TrainingJob:
    """Kick off a background training job for the project."""
    # Check if there's already a running job
    running = db.query(TrainingJob).filter(
        TrainingJob.project_id == project_id,
        TrainingJob.status == "running",
    ).first()
    if running:
        raise HTTPException(409, "A training job is already running for this project")

    # Enforce minimum annotation count (≥ 50)
    reviewed_count = (
        db.query(Annotation)
        .join(Image, Image.id == Annotation.image_id)
        .filter(
            Image.project_id == project_id,
            Annotation.reviewed == True,  # noqa: E712
        )
        .count()
    )
    if reviewed_count < 50:
        raise HTTPException(
            400,
            f"Need at least 50 reviewed annotations to train (you have {reviewed_count}). "
            "Please annotate more images and mark them as reviewed."
        )

    # Clamp epochs to 50–70
    epochs = max(50, min(70, epochs))

    job = TrainingJob(project_id=project_id, status="pending")
    db.add(job)
    db.commit()
    db.refresh(job)

    t = threading.Thread(target=_run_training, args=(job.id, project_id, epochs), daemon=True)
    t.start()
    return job


@router.get("/projects/{project_id}/train/status", response_model=TrainingJobOut)
def get_training_status(
    project_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user_dep),
) -> TrainingJob:
    job = (
        db.query(TrainingJob)
        .filter(TrainingJob.project_id == project_id)
        .order_by(TrainingJob.created_at.desc())
        .first()
    )
    if not job:
        raise HTTPException(404, "No training jobs found for this project")
    return job


@router.get("/projects/{project_id}/annotation-stats")
def get_annotation_stats(
    project_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(current_user_dep),
) -> dict:
    """
    Return per-status image counts and reviewed annotation count.
    Used by the frontend to decide if training threshold is met.
    """
    all_images = db.query(Image).filter(Image.project_id == project_id).all()
    total = len(all_images)
    counts: dict = {}
    for img in all_images:
        counts[img.status] = counts.get(img.status, 0) + 1

    reviewed_count = (
        db.query(Annotation)
        .join(Image, Image.id == Annotation.image_id)
        .filter(
            Image.project_id == project_id,
            Annotation.reviewed == True,  # noqa: E712
        )
        .count()
    )

    latest_version = _load_latest_model_version(project_id, db)
    has_trained_model = latest_version is not None

    return {
        "total": total,
        "unannotated": counts.get("unannotated", 0),
        "in_progress": counts.get("in_progress", 0),
        "annotated": counts.get("annotated", 0),
        "auto_annotated": counts.get("auto_annotated", 0),
        "reviewed_annotation_count": reviewed_count,
        "can_train": reviewed_count >= 50,
        "has_trained_model": has_trained_model,
        "latest_model_version": latest_version.version_number if latest_version else None,
    }


@router.post("/images/{image_id}/auto-annotate", status_code=202)
def auto_annotate_image(
    image_id: int,
    confidence_threshold: float = 0.25,
    db: Session = Depends(get_db),
    user: User = Depends(current_user_dep),
) -> dict:
    """Run inference with the latest trained model on a single image."""
    img = db.query(Image).filter(Image.id == image_id).first()
    if not img:
        raise HTTPException(404, "Image not found")

    latest_version = _load_latest_model_version(img.project_id, db)
    if not latest_version:
        raise HTTPException(
            404,
            "No trained model found for this project. "
            "Train the model first (annotate ≥50 images → Train Model)."
        )

    if not settings.CUSTOM_MODEL_DIR:
        raise HTTPException(500, "CUSTOM_MODEL_DIR not configured.")

    try:
        adapter = _build_adapter(latest_version)
        detections = adapter.predict(img.storage_path, conf=confidence_threshold)
    except Exception as exc:
        raise HTTPException(500, f"Inference error: {exc}")

    classes = db.query(LabelClass).filter(LabelClass.project_id == img.project_id).all()
    name_to_id = {c.name: c.id for c in classes}

    # Remove previous auto-annotations on this image
    db.query(Annotation).filter(
        Annotation.image_id == image_id,
        Annotation.source == "auto",
    ).delete()

    created = 0
    for det in detections:
        ann = Annotation(
            image_id=image_id,
            class_id=name_to_id.get(det.get("class", ""), None),
            shape_type="bbox",
            source="auto",
            confidence=det.get("confidence", 0.0),
            reviewed=False,
            created_by=user.id,
        )
        ann.set_coordinates({
            "x1": det["bbox"][0], "y1": det["bbox"][1],
            "x2": det["bbox"][2], "y2": det["bbox"][3],
        })
        db.add(ann)
        created += 1

    if created > 0:
        img.status = "auto_annotated"
    db.commit()
    return {"created": created, "message": f"{created} auto-annotations created"}


@router.post("/projects/{project_id}/auto-annotate-batch", status_code=202)
def auto_annotate_batch(
    project_id: int,
    confidence_threshold: float = 0.25,
    db: Session = Depends(get_db),
    user: User = Depends(current_user_dep),
) -> dict:
    """
    Run inference on ALL unannotated images in the project using the latest
    trained model. This is the core of the auto-annotation loop.
    """
    latest_version = _load_latest_model_version(project_id, db)
    if not latest_version:
        raise HTTPException(
            404,
            "No trained model found for this project. "
            "Train the model first (annotate ≥50 images → Train Model)."
        )

    if not settings.CUSTOM_MODEL_DIR:
        raise HTTPException(500, "CUSTOM_MODEL_DIR not configured.")

    try:
        adapter = _build_adapter(latest_version)
    except Exception as exc:
        raise HTTPException(500, f"Model load error: {exc}")

    unannotated_images = (
        db.query(Image)
        .filter(
            Image.project_id == project_id,
            Image.status == "unannotated",
        )
        .all()
    )

    if not unannotated_images:
        return {"processed": 0, "total_annotations": 0, "message": "No unannotated images found."}

    classes = db.query(LabelClass).filter(LabelClass.project_id == project_id).all()
    name_to_id = {c.name: c.id for c in classes}

    processed = 0
    total_anns = 0

    for img in unannotated_images:
        try:
            detections = adapter.predict(img.storage_path, conf=confidence_threshold)
        except Exception:
            continue  # skip unreadable images

        created = 0
        for det in detections:
            ann = Annotation(
                image_id=img.id,
                class_id=name_to_id.get(det.get("class", ""), None),
                shape_type="bbox",
                source="auto",
                confidence=det.get("confidence", 0.0),
                reviewed=False,
                created_by=user.id,
            )
            ann.set_coordinates({
                "x1": det["bbox"][0], "y1": det["bbox"][1],
                "x2": det["bbox"][2], "y2": det["bbox"][3],
            })
            db.add(ann)
            created += 1

        if created > 0:
            img.status = "auto_annotated"

        total_anns += created
        processed += 1

    db.commit()
    return {
        "processed": processed,
        "total_annotations": total_anns,
        "message": (
            f"Auto-annotated {processed} images with {total_anns} detections "
            f"using model v{latest_version.version_number}."
        ),
    }
