"""
SQLAlchemy engine + session factory.
Uses a sync engine (SQLite in dev, PostgreSQL in prod).
"""
from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from backend.app.core.config import get_settings

settings = get_settings()

# SQLite requires connect_args to avoid threading issues in the embedded backend
connect_args = (
    {"check_same_thread": False}
    if settings.resolved_database_url.startswith("sqlite")
    else {}
)

engine = create_engine(
    settings.resolved_database_url,
    connect_args=connect_args,
    echo=False,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def db_session() -> Generator[Session, None, None]:
    """Context-manager version — for use outside FastAPI dependency injection."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db() -> None:
    """Create all tables (idempotent)."""
    from backend.app.models import models  # noqa: F401 — registers mapped classes
    Base.metadata.create_all(bind=engine)
